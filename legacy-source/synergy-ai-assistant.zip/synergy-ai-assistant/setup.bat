@echo off
setlocal
cd /d "%~dp0"
echo [1/3] Creating virtual environment...
py -3 -m venv .venv
if errorlevel 1 goto :error
echo [2/3] Updating pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error
echo [3/3] Installing application and AI model dependencies...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error
echo.
echo Installation completed. Start the program with run.bat.
pause
exit /b 0
:error
echo.
echo Installation failed. Check Python 3.10+ and your internet connection.
pause
exit /b 1

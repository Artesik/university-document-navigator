"""Russian text normalization helpers."""

from __future__ import annotations

import re


_TOKEN_RE = re.compile(r"[а-яa-z0-9]+", re.IGNORECASE)
_STOP_WORDS = {
    "а", "без", "бы", "в", "во", "вы", "для", "до", "его", "ее", "если",
    "же", "за", "и", "из", "или", "к", "как", "ко", "мне", "мой", "мы",
    "на", "над", "не", "но", "о", "об", "он", "она", "они", "от", "по",
    "под", "при", "с", "со", "то", "у", "что", "это", "я",
}


def normalize_text(text: str) -> str:
    """Normalize casing, ё and whitespace while preserving useful symbols."""
    return " ".join(text.lower().replace("ё", "е").strip().split())


def tokenize(text: str) -> list[str]:
    """Return meaningful lowercase tokens for the lexical fallback search."""
    return [token for token in _TOKEN_RE.findall(normalize_text(text)) if token not in _STOP_WORDS]


def char_ngrams(text: str, size: int = 3) -> set[str]:
    """Build character n-grams that tolerate Russian word-form changes."""
    compact = normalize_text(text).replace(" ", "_")
    if len(compact) <= size:
        return {compact} if compact else set()
    return {compact[index:index + size] for index in range(len(compact) - size + 1)}

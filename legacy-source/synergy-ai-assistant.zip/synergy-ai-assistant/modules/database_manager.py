"""SQLite persistence and JSON knowledge-base import."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class DatabaseManager:
    def __init__(self, db_path: str | Path, knowledge_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.knowledge_path = Path(knowledge_path)

    def _connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        return connection

    def initialize(self) -> None:
        """Create runtime tables and synchronize public demo knowledge from JSON."""
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS knowledge (
                    id INTEGER PRIMARY KEY,
                    category TEXT NOT NULL,
                    question TEXT NOT NULL,
                    aliases_json TEXT NOT NULL,
                    answer TEXT NOT NULL,
                    steps_json TEXT NOT NULL,
                    source TEXT NOT NULL,
                    department TEXT NOT NULL,
                    keywords_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    query TEXT NOT NULL,
                    knowledge_id INTEGER,
                    score REAL NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    history_id INTEGER NOT NULL,
                    helpful INTEGER NOT NULL,
                    comment TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );
                """
            )
        self.import_knowledge_base()

    def import_knowledge_base(self) -> None:
        if not self.knowledge_path.exists():
            raise FileNotFoundError(f"Knowledge base not found: {self.knowledge_path}")
        payload = json.loads(self.knowledge_path.read_text(encoding="utf-8"))
        items = payload.get("items", payload)
        with self._connect() as connection:
            connection.execute("DELETE FROM knowledge")
            connection.executemany(
                """
                INSERT INTO knowledge
                (id, category, question, aliases_json, answer, steps_json, source, department, keywords_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        item["id"], item["category"], item["question"],
                        json.dumps(item.get("aliases", []), ensure_ascii=False),
                        item["answer"], json.dumps(item.get("steps", []), ensure_ascii=False),
                        item["source"], item["department"],
                        json.dumps(item.get("keywords", []), ensure_ascii=False),
                    )
                    for item in items
                ],
            )

    def get_knowledge_items(self, category: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM knowledge"
        params: tuple[Any, ...] = ()
        if category and category != "Все категории":
            sql += " WHERE category = ?"
            params = (category,)
        sql += " ORDER BY id"
        with self._connect() as connection:
            rows = connection.execute(sql, params).fetchall()
        return [self._decode_item(row) for row in rows]

    def get_categories(self) -> list[str]:
        with self._connect() as connection:
            rows = connection.execute("SELECT DISTINCT category FROM knowledge ORDER BY category").fetchall()
        return [row[0] for row in rows]

    def add_history(self, query: str, knowledge_id: int | None, score: float) -> int:
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO history (query, knowledge_id, score, created_at) VALUES (?, ?, ?, ?)",
                (query, knowledge_id, float(score), _now()),
            )
            return int(cursor.lastrowid)

    def get_history(self, limit: int = 30) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT h.id, h.query, h.knowledge_id, h.score, h.created_at, k.question, k.category
                FROM history h LEFT JOIN knowledge k ON k.id = h.knowledge_id
                ORDER BY h.id DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def clear_history(self) -> None:
        with self._connect() as connection:
            connection.execute("DELETE FROM feedback")
            connection.execute("DELETE FROM history")

    def add_feedback(self, history_id: int, helpful: bool, comment: str = "") -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO feedback (history_id, helpful, comment, created_at) VALUES (?, ?, ?, ?)",
                (history_id, int(helpful), comment.strip(), _now()),
            )

    @staticmethod
    def _decode_item(row: sqlite3.Row) -> dict[str, Any]:
        item = dict(row)
        item["aliases"] = json.loads(item.pop("aliases_json"))
        item["steps"] = json.loads(item.pop("steps_json"))
        item["keywords"] = json.loads(item.pop("keywords_json"))
        return item


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

"""Core modules of the local Synergy assistant."""

__version__ = "1.0.0"

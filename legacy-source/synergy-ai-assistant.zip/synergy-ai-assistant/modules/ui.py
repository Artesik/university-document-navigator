"""CustomTkinter desktop user interface."""

from __future__ import annotations

import threading
from tkinter import messagebox

import customtkinter as ctk

from .database_manager import DatabaseManager
from .feedback_manager import FeedbackManager
from .search_engine import SearchResult, SemanticSearchEngine


COLORS = {
    "navy": "#12324f",
    "navy_dark": "#0b243a",
    "red": "#ef4538",
    "blue": "#2475df",
    "background": "#f4f6f8",
    "surface": "#ffffff",
    "text": "#172536",
    "muted": "#718096",
    "line": "#dfe5eb",
    "success": "#2aa56f",
}


class SynergyAssistantApp(ctk.CTk):
    def __init__(self, database: DatabaseManager, search_engine: SemanticSearchEngine) -> None:
        super().__init__()
        self.database = database
        self.search_engine = search_engine
        self.feedback = FeedbackManager(database)
        self.current_history_id: int | None = None
        self.current_result: SearchResult | None = None
        self.selected_category = "Все категории"

        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        self.title("Интеллектуальный помощник сотрудника — Университет «Синергия»")
        self.geometry("1180x760")
        self.minsize(960, 640)
        self.configure(fg_color=COLORS["background"])
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_main()
        self.show_assistant()

    def _build_sidebar(self) -> None:
        self.sidebar = ctk.CTkFrame(self, width=250, corner_radius=0, fg_color=COLORS["navy"])
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid_rowconfigure(8, weight=1)

        logo = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        logo.grid(row=0, column=0, padx=24, pady=(26, 28), sticky="ew")
        ctk.CTkLabel(
            logo, text="С", width=42, height=42, corner_radius=21,
            fg_color="transparent", text_color="white",
            font=ctk.CTkFont(family="Georgia", size=28, weight="bold"),
        ).grid(row=0, column=0, rowspan=2, padx=(0, 10))
        ctk.CTkLabel(logo, text="УНИВЕРСИТЕТ", text_color="#a9bdcd", font=ctk.CTkFont(size=9)).grid(row=0, column=1, sticky="sw")
        ctk.CTkLabel(logo, text="СИНЕРГИЯ", text_color="white", font=ctk.CTkFont(size=18, weight="bold")).grid(row=1, column=1, sticky="nw")

        self.assistant_nav = self._nav_button("⌁   Помощник", self.show_assistant, 1)
        self.history_nav = self._nav_button("◷   История запросов", self.show_history, 2)
        self.about_nav = self._nav_button("ⓘ   О программе", self.show_about, 3)

        ctk.CTkLabel(
            self.sidebar, text="КАТЕГОРИИ", anchor="w", text_color="#7892a7",
            font=ctk.CTkFont(size=9, weight="bold"),
        ).grid(row=4, column=0, padx=27, pady=(26, 8), sticky="ew")

        self.category_menu = ctk.CTkOptionMenu(
            self.sidebar,
            values=["Все категории", *self.database.get_categories()],
            command=self._set_category,
            fg_color="#1d4363", button_color="#244d6e", button_hover_color="#2b5a80",
            dropdown_fg_color="#173957", text_color="white", width=202, height=38,
        )
        self.category_menu.grid(row=5, column=0, padx=24, sticky="ew")

        status = ctk.CTkFrame(self.sidebar, fg_color="#0d2a43", corner_radius=12)
        status.grid(row=9, column=0, padx=20, pady=14, sticky="sew")
        ctk.CTkLabel(status, text="●", text_color=COLORS["success"], font=ctk.CTkFont(size=15)).grid(row=0, column=0, padx=(13, 8), pady=12)
        ctk.CTkLabel(status, text="Локальный режим", text_color="white", font=ctk.CTkFont(size=11, weight="bold")).grid(row=0, column=1, sticky="w")
        ctk.CTkLabel(status, text="Данные не покидают компьютер", text_color="#819caf", font=ctk.CTkFont(size=8)).grid(row=1, column=0, columnspan=2, padx=13, pady=(0, 11), sticky="w")

        model_text = self.search_engine.engine_name.replace("Sentence Transformers · ", "ИИ: ")
        ctk.CTkLabel(self.sidebar, text=model_text, wraplength=205, justify="left", text_color="#7892a7", font=ctk.CTkFont(size=8)).grid(row=10, column=0, padx=24, pady=(0, 20), sticky="w")

    def _nav_button(self, text: str, command, row: int) -> ctk.CTkButton:
        button = ctk.CTkButton(
            self.sidebar, text=text, command=command, anchor="w", height=42,
            corner_radius=9, fg_color="transparent", hover_color="#1d4566",
            text_color="#d4e0e8", font=ctk.CTkFont(size=12),
        )
        button.grid(row=row, column=0, padx=16, pady=2, sticky="ew")
        return button

    def _build_main(self) -> None:
        self.main = ctk.CTkFrame(self, corner_radius=0, fg_color=COLORS["background"])
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(self.main, height=80, corner_radius=0, fg_color=COLORS["surface"])
        header.grid(row=0, column=0, sticky="ew")
        header.grid_propagate(False)
        header.grid_columnconfigure(0, weight=1)
        self.header_title = ctk.CTkLabel(header, text="Интеллектуальный помощник", text_color=COLORS["text"], font=ctk.CTkFont(size=19, weight="bold"))
        self.header_title.grid(row=0, column=0, padx=34, pady=(18, 0), sticky="w")
        self.header_subtitle = ctk.CTkLabel(header, text="Поиск ответов по демонстрационной базе знаний", text_color=COLORS["muted"], font=ctk.CTkFont(size=10))
        self.header_subtitle.grid(row=1, column=0, padx=34, pady=(0, 16), sticky="w")
        ctk.CTkLabel(header, text="УЧЕБНЫЙ ПРОТОТИП", text_color="#6e7f90", fg_color="#edf1f4", corner_radius=7, font=ctk.CTkFont(size=9, weight="bold"), width=132, height=28).grid(row=0, column=1, rowspan=2, padx=30)

        self.content = ctk.CTkFrame(self.main, corner_radius=0, fg_color=COLORS["background"])
        self.content.grid(row=1, column=0, sticky="nsew")

    def _clear_content(self) -> None:
        for child in self.content.winfo_children():
            child.destroy()
        for nav in (self.assistant_nav, self.history_nav, self.about_nav):
            nav.configure(fg_color="transparent")

    def show_assistant(self) -> None:
        self._clear_content()
        self.assistant_nav.configure(fg_color="#1d4566")
        self.header_title.configure(text="Интеллектуальный помощник")
        self.header_subtitle.configure(text="Введите вопрос обычными словами — модель найдёт близкую по смыслу инструкцию")
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(1, weight=1)

        search_card = ctk.CTkFrame(self.content, fg_color=COLORS["surface"], corner_radius=14, border_width=1, border_color=COLORS["line"])
        search_card.grid(row=0, column=0, padx=34, pady=(28, 14), sticky="ew")
        search_card.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(search_card, text="Чем я могу помочь?", text_color=COLORS["text"], font=ctk.CTkFont(size=17, weight="bold")).grid(row=0, column=0, padx=22, pady=(18, 4), sticky="w")
        ctk.CTkLabel(search_card, text="Не вводите пароли, паспортные данные и другую конфиденциальную информацию.", text_color=COLORS["muted"], font=ctk.CTkFont(size=9)).grid(row=1, column=0, padx=22, sticky="w")

        input_row = ctk.CTkFrame(search_card, fg_color="transparent")
        input_row.grid(row=2, column=0, padx=20, pady=16, sticky="ew")
        input_row.grid_columnconfigure(0, weight=1)
        self.query_entry = ctk.CTkEntry(
            input_row, height=48, placeholder_text="Например: я забыл пароль и не могу войти в личный кабинет",
            border_color="#cdd6df", fg_color="#fbfcfd", text_color=COLORS["text"],
        )
        self.query_entry.grid(row=0, column=0, padx=(0, 10), sticky="ew")
        self.query_entry.bind("<Return>", lambda _event: self._start_search())
        self.search_button = ctk.CTkButton(
            input_row, text="Найти ответ", command=self._start_search, width=130, height=48,
            fg_color=COLORS["blue"], hover_color="#1d63bf", font=ctk.CTkFont(size=11, weight="bold"),
        )
        self.search_button.grid(row=0, column=1)

        self.answer_card = ctk.CTkScrollableFrame(self.content, fg_color=COLORS["surface"], corner_radius=14, border_width=1, border_color=COLORS["line"])
        self.answer_card.grid(row=1, column=0, padx=34, pady=(0, 12), sticky="nsew")
        self.answer_card.grid_columnconfigure(0, weight=1)
        self._show_welcome()

        chips = ctk.CTkFrame(self.content, fg_color="transparent")
        chips.grid(row=2, column=0, padx=34, pady=(0, 24), sticky="ew")
        examples = ["Как восстановить пароль?", "Как загрузить материал в LMS?", "Как изменить расписание?", "Куда направить обращение студента?"]
        for column, example in enumerate(examples):
            chips.grid_columnconfigure(column, weight=1)
            ctk.CTkButton(
                chips, text=example, command=lambda value=example: self._use_example(value),
                height=32, fg_color="#e9eef3", hover_color="#dce6ef", text_color="#526275",
                font=ctk.CTkFont(size=9), corner_radius=8,
            ).grid(row=0, column=column, padx=(0 if column == 0 else 4, 0), sticky="ew")
        self.after(100, self.query_entry.focus_set)

    def _show_welcome(self) -> None:
        ctk.CTkLabel(self.answer_card, text="С", width=48, height=48, corner_radius=14, fg_color=COLORS["navy"], text_color="white", font=ctk.CTkFont(family="Georgia", size=25, weight="bold")).grid(row=0, column=0, pady=(55, 12))
        ctk.CTkLabel(self.answer_card, text="Здравствуйте!", text_color=COLORS["text"], font=ctk.CTkFont(size=19, weight="bold")).grid(row=1, column=0)
        ctk.CTkLabel(self.answer_card, text="Я найду подходящую инструкцию, источник и ответственное подразделение.\nОтветы выбираются из локальной базы и не генерируются произвольно.", justify="center", text_color=COLORS["muted"], font=ctk.CTkFont(size=11), wraplength=580).grid(row=2, column=0, pady=(7, 45))

    def _set_category(self, value: str) -> None:
        self.selected_category = value

    def _use_example(self, text: str) -> None:
        self.query_entry.delete(0, "end")
        self.query_entry.insert(0, text)
        self._start_search()

    def _start_search(self) -> None:
        query = self.query_entry.get().strip()
        if len(query) < 3:
            messagebox.showinfo("Введите вопрос", "Сформулируйте вопрос длиной не менее трёх символов.")
            return
        self.search_button.configure(state="disabled", text="Ищу…")
        for child in self.answer_card.winfo_children():
            child.destroy()
        ctk.CTkLabel(self.answer_card, text="Анализирую смысл запроса…", text_color=COLORS["muted"], font=ctk.CTkFont(size=12)).grid(row=0, column=0, pady=70)
        threading.Thread(target=self._perform_search, args=(query,), daemon=True).start()

    def _perform_search(self, query: str) -> None:
        result = self.search_engine.search(query, self.selected_category)
        history_id = self.database.add_history(query, result.item["id"] if result.item else None, result.score)
        self.after(0, lambda: self._render_result(result, history_id))

    def _render_result(self, result: SearchResult, history_id: int) -> None:
        self.current_result = result
        self.current_history_id = history_id
        self.search_button.configure(state="normal", text="Найти ответ")
        for child in self.answer_card.winfo_children():
            child.destroy()
        if result.item is None:
            ctk.CTkLabel(self.answer_card, text="Подходящий ответ не найден", text_color=COLORS["text"], font=ctk.CTkFont(size=18, weight="bold")).grid(row=0, column=0, pady=(55, 8))
            ctk.CTkLabel(self.answer_card, text="Попробуйте уточнить формулировку, выбрать другую категорию\nили обратиться к профильному подразделению.", justify="center", text_color=COLORS["muted"], font=ctk.CTkFont(size=11)).grid(row=1, column=0)
            self._add_score_label(result, 2)
            return

        item = result.item
        title_row = ctk.CTkFrame(self.answer_card, fg_color="transparent")
        title_row.grid(row=0, column=0, padx=22, pady=(18, 8), sticky="ew")
        title_row.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(title_row, text=item["question"], text_color=COLORS["text"], font=ctk.CTkFont(size=16, weight="bold"), anchor="w", wraplength=650, justify="left").grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(title_row, text=item["category"], text_color="#256bbb", fg_color="#edf5ff", corner_radius=7, height=25, font=ctk.CTkFont(size=9)).grid(row=0, column=1, padx=(12, 0))
        ctk.CTkLabel(self.answer_card, text=item["answer"], text_color="#34465b", font=ctk.CTkFont(size=11), justify="left", anchor="w", wraplength=720).grid(row=1, column=0, padx=22, pady=(0, 13), sticky="ew")

        if item.get("steps"):
            steps_frame = ctk.CTkFrame(self.answer_card, fg_color="#f5f7fa", corner_radius=10)
            steps_frame.grid(row=2, column=0, padx=22, pady=4, sticky="ew")
            ctk.CTkLabel(steps_frame, text="Порядок действий", text_color=COLORS["text"], font=ctk.CTkFont(size=10, weight="bold")).grid(row=0, column=0, padx=15, pady=(12, 5), sticky="w")
            for index, step in enumerate(item["steps"], start=1):
                ctk.CTkLabel(steps_frame, text=f"{index}", width=22, height=22, corner_radius=11, fg_color="#dceafb", text_color="#286aba", font=ctk.CTkFont(size=9, weight="bold")).grid(row=index, column=0, padx=(15, 8), pady=4)
                ctk.CTkLabel(steps_frame, text=step, text_color="#46586c", font=ctk.CTkFont(size=10), anchor="w", justify="left", wraplength=650).grid(row=index, column=1, padx=(0, 15), pady=4, sticky="w")
            ctk.CTkLabel(steps_frame, text="", height=5).grid(row=len(item["steps"]) + 1, column=0)

        source_frame = ctk.CTkFrame(self.answer_card, fg_color="#f8fafc", corner_radius=9, border_width=1, border_color="#e3e9ef")
        source_frame.grid(row=3, column=0, padx=22, pady=(13, 8), sticky="ew")
        ctk.CTkLabel(source_frame, text="Источник", text_color=COLORS["muted"], font=ctk.CTkFont(size=8)).grid(row=0, column=0, padx=13, pady=(8, 0), sticky="w")
        ctk.CTkLabel(source_frame, text=item["source"], text_color="#34465b", font=ctk.CTkFont(size=10, weight="bold")).grid(row=1, column=0, padx=13, pady=(0, 3), sticky="w")
        ctk.CTkLabel(source_frame, text=f"Ответственное подразделение: {item['department']}", text_color=COLORS["muted"], font=ctk.CTkFont(size=9)).grid(row=2, column=0, padx=13, pady=(0, 9), sticky="w")

        feedback_row = ctk.CTkFrame(self.answer_card, fg_color="transparent")
        feedback_row.grid(row=4, column=0, padx=22, pady=(4, 15), sticky="ew")
        ctk.CTkLabel(feedback_row, text="Ответ был полезен?", text_color=COLORS["muted"], font=ctk.CTkFont(size=9)).grid(row=0, column=0, padx=(0, 8))
        ctk.CTkButton(feedback_row, text="Да", width=55, height=27, command=lambda: self._submit_feedback(True), fg_color="#e9f7f0", hover_color="#d7f0e3", text_color="#21865b", font=ctk.CTkFont(size=9)).grid(row=0, column=1, padx=2)
        ctk.CTkButton(feedback_row, text="Нет", width=55, height=27, command=lambda: self._submit_feedback(False), fg_color="#fff0ef", hover_color="#f9dedb", text_color="#c5433d", font=ctk.CTkFont(size=9)).grid(row=0, column=2, padx=2)
        self._add_score_label(result, 4, align_right=True)

    def _add_score_label(self, result: SearchResult, row: int, align_right: bool = False) -> None:
        label = ctk.CTkLabel(self.answer_card, text=f"Режим: {result.engine}  ·  уверенность {result.score:.0%}", text_color="#9aa5b1", font=ctk.CTkFont(size=8))
        label.grid(row=row, column=0, padx=22, pady=8, sticky="e" if align_right else "")

    def _submit_feedback(self, helpful: bool) -> None:
        if self.feedback.submit(self.current_history_id, helpful):
            messagebox.showinfo("Спасибо", "Оценка сохранена локально и будет учтена при улучшении базы знаний.")

    def show_history(self) -> None:
        self._clear_content()
        self.history_nav.configure(fg_color="#1d4566")
        self.header_title.configure(text="История запросов")
        self.header_subtitle.configure(text="История хранится только в локальной базе SQLite")
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(1, weight=1)
        toolbar = ctk.CTkFrame(self.content, fg_color="transparent")
        toolbar.grid(row=0, column=0, padx=34, pady=(25, 10), sticky="ew")
        toolbar.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(toolbar, text="Последние обращения", text_color=COLORS["text"], font=ctk.CTkFont(size=16, weight="bold")).grid(row=0, column=0, sticky="w")
        ctk.CTkButton(toolbar, text="Очистить историю", command=self._clear_history, width=120, height=32, fg_color="#e9eef3", hover_color="#dde5ec", text_color="#536274", font=ctk.CTkFont(size=9)).grid(row=0, column=1)
        frame = ctk.CTkScrollableFrame(self.content, fg_color=COLORS["surface"], corner_radius=14, border_width=1, border_color=COLORS["line"])
        frame.grid(row=1, column=0, padx=34, pady=(0, 30), sticky="nsew")
        frame.grid_columnconfigure(0, weight=1)
        history = self.database.get_history()
        if not history:
            ctk.CTkLabel(frame, text="История пока пуста", text_color=COLORS["muted"], font=ctk.CTkFont(size=13)).grid(row=0, column=0, pady=70)
        for row, item in enumerate(history):
            card = ctk.CTkFrame(frame, fg_color="#f8fafc", corner_radius=9)
            card.grid(row=row, column=0, padx=12, pady=(10 if row == 0 else 4, 4), sticky="ew")
            card.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(card, text=item["query"], text_color=COLORS["text"], font=ctk.CTkFont(size=11, weight="bold"), anchor="w").grid(row=0, column=0, padx=13, pady=(9, 2), sticky="ew")
            result_text = item["question"] or "Подходящий ответ не найден"
            ctk.CTkLabel(card, text=f"{result_text}  ·  {item['score']:.0%}", text_color=COLORS["muted"], font=ctk.CTkFont(size=9), anchor="w").grid(row=1, column=0, padx=13, pady=(0, 9), sticky="ew")

    def _clear_history(self) -> None:
        if messagebox.askyesno("Очистить историю", "Удалить всю историю запросов и связанные оценки?"):
            self.database.clear_history()
            self.show_history()

    def show_about(self) -> None:
        self._clear_content()
        self.about_nav.configure(fg_color="#1d4566")
        self.header_title.configure(text="О программе")
        self.header_subtitle.configure(text="Локальный учебный прототип · версия 1.0.0")
        card = ctk.CTkFrame(self.content, fg_color=COLORS["surface"], corner_radius=14, border_width=1, border_color=COLORS["line"])
        card.pack(fill="both", expand=True, padx=34, pady=28)
        ctk.CTkLabel(card, text="Интеллектуальный помощник сотрудника", text_color=COLORS["text"], font=ctk.CTkFont(size=21, weight="bold")).pack(pady=(45, 8))
        ctk.CTkLabel(card, text="Университет «Синергия»", text_color=COLORS["red"], font=ctk.CTkFont(size=14, weight="bold")).pack()
        description = (
            "Приложение демонстрирует применение нейросетевой модели Sentence Transformers для смыслового поиска "
            "по локальной базе инструкций. Модель не генерирует новые сведения: пользователь получает только "
            "контролируемый ответ, источник и ответственное подразделение.\n\n"
            "В прототипе используются исключительно условные и общедоступные демонстрационные данные. "
            "Интеграция с реальными системами Университета не проводилась."
        )
        ctk.CTkLabel(card, text=description, wraplength=650, justify="center", text_color="#526275", font=ctk.CTkFont(size=11)).pack(pady=25)
        features = "Python  ·  CustomTkinter  ·  Sentence Transformers  ·  SQLite  ·  полностью локальная работа"
        ctk.CTkLabel(card, text=features, text_color="#718096", fg_color="#f2f5f8", corner_radius=9, height=38, font=ctk.CTkFont(size=9)).pack(padx=40, fill="x")


__all__ = ["SynergyAssistantApp"]

"""Entry point for the Synergy Employee AI Assistant desktop application."""

from __future__ import annotations

import sys
from pathlib import Path

from modules.database_manager import DatabaseManager
from modules.search_engine import SemanticSearchEngine


BASE_DIR = Path(__file__).resolve().parent


def main() -> int:
    try:
        from modules.ui import SynergyAssistantApp
    except ImportError as exc:
        print(
            "Не удалось загрузить графический интерфейс. "
            "Установите зависимости: pip install -r requirements.txt",
            file=sys.stderr,
        )
        print(f"Техническая информация: {exc}", file=sys.stderr)
        return 1

    database = DatabaseManager(
        db_path=BASE_DIR / "database" / "assistant.db",
        knowledge_path=BASE_DIR / "database" / "knowledge_base.json",
    )
    database.initialize()
    engine = SemanticSearchEngine(database.get_knowledge_items())
    app = SynergyAssistantApp(database=database, search_engine=engine)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run setup.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install pyinstaller==6.16.0
if errorlevel 1 goto :error
".venv\Scripts\pyinstaller.exe" SynergyAssistant.spec --noconfirm
if errorlevel 1 goto :error
echo.
echo Build completed: dist\SynergyAssistant\SynergyAssistant.exe
pause
exit /b 0
:error
echo Build failed.
pause
exit /b 1
